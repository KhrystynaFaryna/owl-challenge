#!/usr/bin/env bash
#
# Builds the algorithm's Docker image, boots it as an HTTP server that
# implements Grand Challenge's "invoke" API, then exercises it against each
# configured interface. For each interface this script:
#   1. stages the interface's input files into the container's /input mount
#   2. calls POST /invoke and checks for a success response (HTTP 201 Created)
#   3. copies whatever the container wrote to /output back to the host
#
# Run this after changing the algorithm to confirm the container still
# behaves correctly before uploading it (see ./do_save.sh).

# Exit immediately on: an error in any command, use of an unset variable,
# or a failure in any stage of a pipeline (not just the last stage).
set -euo pipefail

SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
DOCKER_IMAGE_TAG="example_algorithm_sanity-check"
CONTAINER_NAME="example_algorithm_sanity-check_container"

INPUT_DIR="${SCRIPT_DIR}/test/input"
OUTPUT_DIR="${SCRIPT_DIR}/test/output"

# Staging directories are bind-mounted into the container as /input and /output.
# They start empty and are (re)provisioned with hard-linked input files right
# before each invocation — mimicking how Grand Challenge provisions inputs.
STAGING_INPUT_DIR="${SCRIPT_DIR}/test/.staging_input"
STAGING_OUTPUT_DIR="${SCRIPT_DIR}/test/.staging_output"

# How long to wait for the container's /health endpoint to come up.
# These match the timeouts used on Grand Challenge.
HEALTH_CHECK_MAX_ATTEMPTS=30
HEALTH_CHECK_DELAY_SECONDS=5
HEALTH_CHECK_TIMEOUT_SECONDS=10

# How long a single /invoke call is allowed to run.
# Note that this is NOT equivalent to the maximum runtime set for jobs on Grand Challenge
# The maximum runtime on Grand Challenge includes I/O as well as model and auxiliary data loading.
# Locally (when running this script) it only includes inference (I/O, model and auxiliary data loading happen before).
INVOKE_TIMEOUT_SECONDS=300

# --- Globals set by setup() -------------------------------------------------
LOG_LINES_SHOWN=0
DOCKER_VOLUME_TAG=""
DOCKER_NETWORK_TAG=""
TESTER_NAME=""
CONTAINER_PORT=4743
BASE_URL=""
GPU_ARGS=""
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

main() {
    # Prepare staging dirs, Docker network, and detect GPU support
    setup
    trap cleanup EXIT

    build_container
    start_container

    # Poll /health until the server signals it's ready
    check_health


    # Copy this interface's input files into the container
    provision "interf0"
    # Call POST /invoke and wait for inference completion
    invoke
    # Copy the results back to the host
    collect_output "interf0"


    log "Save this image for uploading via ./do_save.sh"
}

# ---------------------------------------------------------------------------
# Helper Functions
# ---------------------------------------------------------------------------

# Log a message to stdout with color based on level (when running in a terminal).
#   info    = blue (default)
#   warning = yellow
#   error   = red
log() {
    local message="$1"
    local level="${2:-info}"
    if [[ -t 1 ]]; then
        case "$level" in
            info)    printf "\e[38;2;36;150;237m> %s\e[0m\n" "$message" ;;
            warning) printf "\e[38;2;255;200;0m> %s\e[0m\n" "$message" ;;
            error)   printf "\e[38;2;255;50;50m> %s\e[0m\n" "$message" ;;
            *)       printf "\e[38;2;36;150;237m> %s\e[0m\n" "$message" ;;
        esac
    else
        printf "%s\n" "$message"
    fi
}

setup() {
    log "Setup ..."

    # Allow the Docker user to read these on the host
    chmod -R -f o+rX "$INPUT_DIR" "${SCRIPT_DIR}/model"

    # Disable promotional logs from Docker
    export DOCKER_CLI_HINTS=false

    # Detect whether the NVIDIA GPU runtime is available.
    # On macOS or machines without nvidia-container-runtime, --gpus all would
    # prevent the container from starting. In that case we skip the flag and
    # the algorithm will run on CPU (torch.cuda.is_available() returns False).
    # This does not affect the exported container — on Grand Challenge your
    # algorithm will always have GPU access.
    if docker info 2>/dev/null | grep -q "Runtimes:.*nvidia"; then
        GPU_ARGS="--gpus all"
        log "NVIDIA runtime detected — enabling GPU access"
    else
        GPU_ARGS=""
        log "No NVIDIA runtime detected — running on CPU (this is fine for testing)" warning
    fi

    # Create empty staging directories for the /input and /output bind mounts
    rm -rf "$STAGING_INPUT_DIR" "$STAGING_OUTPUT_DIR"
    mkdir -m o+rwX "$STAGING_INPUT_DIR"
    mkdir -m o+rwX "$STAGING_OUTPUT_DIR"

    # A scratch volume that mimics the ephemeral /tmp on Grand Challenge
    DOCKER_VOLUME_TAG="${DOCKER_IMAGE_TAG}-scratch"
    docker volume create "$DOCKER_VOLUME_TAG" > /dev/null

    # The container's listening port, and the URL the tester sidecar uses
    # to reach it (resolved by container name via Docker's embedded DNS).
    BASE_URL="http://${CONTAINER_NAME}:${CONTAINER_PORT}"

    # An isolated network that mimics the network restrictions on Grand Challenge.
    # The algorithm container has no internet access, just like in production.
    DOCKER_NETWORK_TAG="${DOCKER_IMAGE_TAG}-isolated"
    docker network create --internal "$DOCKER_NETWORK_TAG" > /dev/null

    # The tester sidecar: lives on the isolated network so it can reach the
    # algorithm container by name, and is how we issue health/invoke checks
    # without needing the host to route into that network.
    TESTER_NAME="${DOCKER_IMAGE_TAG}-tester"
    docker run --detach --name "$TESTER_NAME" \
        --network "$DOCKER_NETWORK_TAG" \
        curlimages/curl:latest sleep infinity > /dev/null 2>&1
}

cleanup() {
    log "Cleanup ..."

    docker rm -f "$CONTAINER_NAME" >/dev/null 2>&1 || true
    docker rm -f "$TESTER_NAME" >/dev/null 2>&1 || true
    log "Containers stopped"

    # Remove staging directories
    rm -rf "$STAGING_INPUT_DIR"
    # Staging output may contain files owned by the container's UID on Linux
    docker run --rm --platform=linux/amd64 --quiet --user root \
        --volume "$STAGING_OUTPUT_DIR":/output \
        --entrypoint /bin/sh \
        $DOCKER_IMAGE_TAG \
        -c "rm -rf /output/* || true" 2>/dev/null || true
    rm -rf "$STAGING_OUTPUT_DIR"

    # Remove volumes and network
    docker volume rm "$DOCKER_VOLUME_TAG" > /dev/null 2>&1 || true
    docker network rm "$DOCKER_NETWORK_TAG" > /dev/null 2>&1 || true
}

build_container() {
    log "(Re)build the container"
    source "${SCRIPT_DIR}/do_build.sh"

    log "Verifying container labels"
    local api_method
    api_method=$(docker inspect \
        --format='{{index .Config.Labels "org.grand-challenge.api-method"}}' \
        "$DOCKER_IMAGE_TAG" 2>/dev/null || echo "")

    if [ "$api_method" != "invoke" ]; then
        log "ERROR: The container image is missing the required label:" error
        log "  LABEL org.grand-challenge.api-method=\"invoke\"" error
        log "" error
        log "Without this label, Grand Challenge will not recognize that your" error
        log "container implements the invoke API and will default to exec mode." error
        log "Please add this label to your Dockerfile." error
        exit 1
    fi
}

start_container() {
    log "Starting container"

    # Extra arguments worth calling out:
    #   --network <isolated>               no internet access; the tester sidecar issues
    #                                      HTTP requests to the container by name via
    #                                      Docker's embedded DNS
    #   --volume <vol>:/tmp                scratch space (Grand Challenge disallows writes
    #                                      elsewhere outside the mounted directories)
    #   --volume model:/opt/ml/model:ro    the (optional) model tarball
    local docker_run_args=(
        --detach
        --name "$CONTAINER_NAME"
        ${GPU_ARGS:+$GPU_ARGS}
        --platform=linux/amd64
        --volume "${SCRIPT_DIR}/model":/opt/ml/model:ro
        --volume "$STAGING_INPUT_DIR":/input:ro
        --volume "$STAGING_OUTPUT_DIR":/output
        --volume "$DOCKER_VOLUME_TAG":/tmp
        --network "$DOCKER_NETWORK_TAG"
    )

    docker run "${docker_run_args[@]}" "$DOCKER_IMAGE_TAG" >/dev/null

    log "Container started; reachable from tester sidecar at ${BASE_URL}"
}

flush_docker_log() {
    # Prints any container log lines that haven't been shown yet.
    local total_lines new_lines
    total_lines=$(docker logs "$CONTAINER_NAME" 2>&1 | wc -l)
    new_lines=$((total_lines - LOG_LINES_SHOWN))

    if (( new_lines > 0 )); then
        docker logs --timestamps --tail "$new_lines" "$CONTAINER_NAME"
    fi

    LOG_LINES_SHOWN=$total_lines
}

http_status() {
    # Issues a request from inside the tester sidecar (not the host).
    local method="$1"
    local timeout_seconds="$2"
    local url="$3"

    docker exec "$TESTER_NAME" \
        curl -s -o /dev/null -w "%{http_code}" --max-time "$timeout_seconds" \
        -X "$method" "$url" \
      || echo "000"
}

check_health() {
    log "Waiting for health endpoint..."

    local status
    for ((i = 1; i <= HEALTH_CHECK_MAX_ATTEMPTS; i++)); do
        status=$(http_status "GET" "$HEALTH_CHECK_TIMEOUT_SECONDS" "${BASE_URL}/health")
        log "Health check attempt $i/${HEALTH_CHECK_MAX_ATTEMPTS} returned $status"

        if [[ "$status" == "200" ]]; then
            log "API healthy"
            flush_docker_log
            return 0
        fi

        if [[ "$status" == "302" ]]; then
            log "Health endpoint returned HTTP 302 — failing" error
            flush_docker_log
            return 1
        fi

        log "Retrying in ${HEALTH_CHECK_DELAY_SECONDS}s"
        sleep "$HEALTH_CHECK_DELAY_SECONDS"
    done

    log "Health endpoint never returned HTTP 200" error
    flush_docker_log
    return 1
}

provision() {
    local interface_dir="$1"
    log "Provisioning input for ${interface_dir}"

    # Clear /output inside the container (host can't due to UID mismatch on Linux)
    docker exec --user root "$CONTAINER_NAME" /bin/sh -c "rm -rf /output/*"

    # Clear the input staging dir, then hard-link this interface's input files in
    rm -rf "${STAGING_INPUT_DIR:?}"/*
    cp -rl "${INPUT_DIR}/${interface_dir}/." "$STAGING_INPUT_DIR/"
}

invoke() {
    log "Calling invoke endpoint..."

    local status
    status=$(http_status "POST" "$INVOKE_TIMEOUT_SECONDS" "${BASE_URL}/invoke")
    flush_docker_log

    if [ "$status" != "201" ]; then
        log "Invoke failed (expected HTTP 201 Created, got $status)" error
        exit 1
    fi

    log "Invoke completed"
}

collect_output() {
    local interface_dir="$1"
    local destination="${OUTPUT_DIR}/${interface_dir}"
    log "Collecting output for ${interface_dir}"

    if [ -d "$destination" ]; then
        # Clean up any earlier collected output using a container (handles
        # files owned by the container's UID on Linux)
        docker run --rm --platform=linux/amd64 --quiet --user root \
            --volume "$destination":/output \
            --entrypoint /bin/sh \
            $DOCKER_IMAGE_TAG \
            -c "rm -rf /output/* || true"
    else
        mkdir -p -m o+rwX "$destination"
    fi

    # Fix permissions so the host user can read the output files.
    # The container may have written them as a different UID on Linux.
    docker exec --user root "$CONTAINER_NAME" \
        /bin/sh -c "chmod -R -f o+rX /output/*"

    # Copy from the staging directory to the host output directory
    cp -r "$STAGING_OUTPUT_DIR/." "${destination}/"
    log "Wrote results to ${OUTPUT_DIR}/"
}

# ---------------------------------------------------------------------------

main
